import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { getAppBase } from '@uipath/uipath-typescript'
import './index.css'
import App from './App'

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error('Root element not found');
}

createRoot(rootElement).render(
  <StrictMode>
    <BrowserRouter basename={getAppBase()}>
      <App />
    </BrowserRouter>
  </StrictMode>,
)
